console.log("hellow world!!");
var calculator = require('./calc');

var a=10, b=5;
 
console.log("Addition : "+calculator.add(a,b));
console.log("Subtraction : "+calculator.sub(a,b));
console.log("Multiplication : "+calculator.multiply(a,b));
