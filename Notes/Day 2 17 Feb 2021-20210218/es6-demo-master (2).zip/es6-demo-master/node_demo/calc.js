//calc
var add = function (a, b) {
    return a+b;
}; 
 
// Returns difference of two numbers
var subtract = function (a, b) {
    return a-b;
}; 
 
// Returns product of two numbers
exports.multiply = function (a, b) {
    return a*b;
};

exports.add =  add;
exports.sub = subtract;