function  addition(a, b = 10){
    return a+b;
}

var sum = addition(23);
var sum1 = addition(2, 5);
console.log(sum1);
console.log(sum);