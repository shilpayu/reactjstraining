
// //const object = {a:'objectinitializer', b: 100, c: 'javascript'};
// console.log(object.a);
// console.log(object.b);
// console.log(object.c);
// console.log(object);

 const a1 = 'object value';
 const  b1 = 100;

// const object = {a : a1, b : b1};
// console.log(object.a);
// console.log(object.b);

//es6
const object = {a1, b1};
console.log("Object ",object);