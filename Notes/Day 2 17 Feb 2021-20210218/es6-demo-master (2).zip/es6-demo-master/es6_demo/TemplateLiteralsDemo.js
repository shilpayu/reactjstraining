
// console.log('this is my first learning\n'+'javascript example');

//es6
console.log(`this is my first learning
javascript example`);

var studentName = "Kavita";
var marks = 30;
var graceMarks = 5;

console.log(studentName+" has "+ marks +" marks");

//es6
console.log(`${studentName} has ${marks+graceMarks} marks`);