//demo for calculator

import {addition,subtraction} from "./calc.js"

var a = 10, b = 20;

console.log(addition(a,b));
console.log(subtraction(b,a));
// console.log(multiplication(a,b));