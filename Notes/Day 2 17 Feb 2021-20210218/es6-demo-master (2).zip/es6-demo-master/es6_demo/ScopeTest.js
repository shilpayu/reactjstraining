//var 

// var message= "hello world";
// console.log(message);

// function printMessage() {
//     var message1 = "inside printMessage"
//     console.log(message1);
// }
// printMessage();

// console.log(message1);

// let message = "hello world";

// function printMessage(){
//     let message1 = "jdkf";
//     console.log(message1);
// }
// printMessage()
// console.log(message1);

const message = "constant value";
const message = "jk";
//message = "jkjk";


function printMessage(){
    const message1 = "jdkf";
    console.log(message1);
}
console.log(message1);
