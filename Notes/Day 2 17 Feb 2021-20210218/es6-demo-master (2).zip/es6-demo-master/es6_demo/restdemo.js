function restDemo(a, b,...c){ //... is the syntax for the rest parameter
    console.log(c[2]);
    console.log(d);
}
//1,2,3,4,5,6,7

restDemo(1,2,3,4,5,6,7);
