var underscoreObj = require('underscore');
var arr = [45,2,90,1,68];
var maxvalue = underscoreObj.max(arr);
console.log('maximum value from array', maxvalue);